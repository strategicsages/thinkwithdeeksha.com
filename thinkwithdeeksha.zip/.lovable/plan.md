Restore the career section to a clean vertical arc that matches the warm editorial design guidelines. Remove the horizontal scroll-snap Chronicle and the 4-tile bento bridge that added too many boxes between Capabilities and the timeline.

Changes to `src/routes/about.tsx`

1. Delete the bento bridge section (the 4 stat tiles with Calendar / Users / Sparkles / Globe icons).
2. Replace the horizontal scroll-snap timeline with a single vertical arc:
   - One section header: small "Chronicle" eyebrow + `The arc.` headline (no "Swipe to travel back" hint, no progress counter).
   - A vertical hairline spine on the left with petrol node markers, one per role.
   - Each entry stacks vertically: mono year label, domain eyebrow, company, italic role, summary paragraph, outcomes list with petrol hairline bullets.
   - First node filled petrol; remaining nodes ivory with hairline border (matches current node treatment).
3. Keep all existing content (TIMELINE data, Capabilities section, Education, Languages) untouched.
4. Clean up `src/styles.css`: remove the now-unused `.timeline-scroller` utility.

Visual rules preserved
- Warm ivory background, hairline borders, petrol as accent only.
- No filled colored tiles; no decorative motion; subtle reveal only.
- Capabilities flows directly into the vertical arc with a single hairline divider — no intermediate stat grid.

Validation
- Load `/about` in the preview, confirm a single calm vertical timeline replaces the horizontal scroller, and no orphan boxes remain between Capabilities and the arc.